!EDOGOSAPP 1.1
\\\CONFIG
{
    "name": "Image Editor",
    "customIcon": "/usr/share/icons/16/imgedit.png",
    "icon": "🖼️",
    "width": 1180,
    "height": 780
}
\\\ENDCONFIG
\\\CODESTART
<style>
    :root {
        --bg-0: #17161a;
        --bg-1: #1e1d22;
        --bg-2: #26242b;
        --bg-3: #302d36;
        --line: #3a3640;
        --line-hi: #4a4552;
        --ink: #e7e2d5;
        --ink-dim: #8b8699;
        --ink-faint: #5e5a68;
        --accent: #e8a34a;
        --accent-hot: #f2b85c;
        --accent-dim: #a67535;
        --danger: #d95454;
        --ok: #7ab06f;
        --radius: 4px;
        --radius-lg: 6px;
        --mono: ui-monospace, "SF Mono", "JetBrains Mono", Menlo, Consolas, monospace;
        --sans: ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
    }

    * { box-sizing: border-box; }
    html, body {
        margin: 0; padding: 0; height: 100%; overflow: hidden;
        background: var(--bg-0);
        color: var(--ink);
        font-family: var(--sans);
        font-size: 12.5px;
        user-select: none;
    }

    /* Shell */
    #app {
        display: grid;
        grid-template-rows: 34px 1fr 22px;
        height: 100vh;
    }

    /* Menubar */
    .menubar {
        display: flex;
        align-items: center;
        background: linear-gradient(180deg, #252328 0%, #1c1b1f 100%);
        border-bottom: 1px solid var(--line);
        padding: 0 4px;
        gap: 1px;
    }
    .mb-brand {
        font-family: var(--mono);
        font-size: 10px;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        color: var(--accent);
        padding: 0 12px 0 8px;
        border-right: 1px solid var(--line);
        height: 100%;
        display: flex;
        align-items: center;
        margin-right: 4px;
    }
    .mb-btn {
        background: none; border: none; color: var(--ink);
        padding: 6px 10px; font-size: 12px; font-family: var(--sans);
        border-radius: var(--radius); cursor: pointer;
        position: relative;
    }
    .mb-btn:hover { background: var(--bg-3); }
    .mb-btn[disabled] { color: var(--ink-faint); cursor: not-allowed; }
    .mb-btn[disabled]:hover { background: transparent; }

    .mb-spacer { flex: 1; }
    .mb-right {
        font-family: var(--mono);
        font-size: 10.5px;
        color: var(--ink-dim);
        padding: 0 10px;
    }

    /* Dropdown menu */
    .dropdown {
        position: absolute; top: 30px; left: 0;
        background: var(--bg-2);
        border: 1px solid var(--line-hi);
        border-radius: var(--radius);
        box-shadow: 0 8px 24px rgba(0,0,0,0.5);
        padding: 4px;
        min-width: 180px;
        display: none;
        z-index: 100;
    }
    .dropdown.open { display: block; }
    .dd-item {
        display: flex; align-items: center; justify-content: space-between;
        padding: 6px 10px; border-radius: 3px; cursor: pointer;
        font-size: 12px;
    }
    .dd-item:hover { background: var(--accent-dim); color: #fff; }
    .dd-item .sh {
        font-family: var(--mono); font-size: 10.5px;
        color: var(--ink-faint); margin-left: 24px;
    }
    .dd-item:hover .sh { color: rgba(255,255,255,0.7); }
    .dd-sep { height: 1px; background: var(--line); margin: 4px 2px; }

    /* Workspace */
    .workspace {
        display: grid;
        grid-template-columns: 44px 1fr 250px;
        overflow: hidden;
    }

    /* Left tool column */
    .tools {
        background: var(--bg-1);
        border-right: 1px solid var(--line);
        padding: 6px 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 2px;
    }
    .tool {
        width: 32px; height: 32px;
        display: flex; align-items: center; justify-content: center;
        font-size: 17px; cursor: pointer; border-radius: var(--radius);
        color: var(--ink-dim);
        transition: background 0.08s, color 0.08s;
    }
    .tool:hover { background: var(--bg-3); color: var(--ink); }
    .tool.active {
        background: var(--accent-dim); color: #fff;
        box-shadow: inset 0 0 0 1px var(--accent);
    }
    .tool-sep { width: 24px; height: 1px; background: var(--line); margin: 4px 0; }

    /* Canvas area */
    .canvas-area {
        position: relative;
        background:
            repeating-conic-gradient(#222 0 25%, #2a2a2a 0 50%) 50% / 20px 20px,
            #1a1a1a;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .canvas-area::before {
        content: '';
        position: absolute; inset: 0;
        background: radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.45) 100%);
        pointer-events: none;
    }
    .canvas-wrap {
        position: relative;
        transform-origin: center;
        transition: transform 0.15s ease;
        box-shadow: 0 8px 32px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.06);
    }
    #preview {
        display: block;
        max-width: none;
        image-rendering: pixelated;
        image-rendering: -moz-crisp-edges;
    }
    .empty-state {
        text-align: center;
        color: var(--ink-dim);
        font-family: var(--mono);
        font-size: 11px;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        position: absolute;
        top: 50%; left: 50%; transform: translate(-50%, -50%);
        pointer-events: none;
    }
    .empty-state .big {
        font-size: 48px; margin-bottom: 18px;
        filter: grayscale(1) opacity(0.5);
    }
    .empty-state .act {
        margin-top: 16px; color: var(--accent);
        pointer-events: auto;
    }
    .empty-state .act button {
        background: transparent;
        color: var(--accent);
        border: 1px solid var(--accent-dim);
        padding: 8px 16px;
        font-family: var(--mono);
        font-size: 10.5px;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        cursor: pointer;
        border-radius: var(--radius);
        margin: 0 4px;
        transition: all 0.12s;
    }
    .empty-state .act button:hover {
        background: var(--accent);
        color: #1a1612;
    }

    /* Zoom HUD */
    .zoom-hud {
        position: absolute; bottom: 10px; left: 50%;
        transform: translateX(-50%);
        display: flex; align-items: center; gap: 2px;
        background: rgba(20, 18, 22, 0.85);
        backdrop-filter: blur(8px);
        border: 1px solid var(--line);
        border-radius: var(--radius-lg);
        padding: 3px;
        z-index: 5;
    }
    .zoom-hud button {
        background: none; border: none; color: var(--ink-dim);
        width: 26px; height: 24px; cursor: pointer; border-radius: 3px;
        font-family: var(--mono); font-size: 12px;
    }
    .zoom-hud button:hover { background: var(--bg-3); color: var(--ink); }
    .zoom-val {
        font-family: var(--mono); font-size: 10.5px;
        color: var(--ink); min-width: 56px; text-align: center;
        padding: 0 6px;
    }

    /* Inspector panel */
    .inspector {
        background: var(--bg-1);
        border-left: 1px solid var(--line);
        overflow-y: auto;
        display: flex;
        flex-direction: column;
    }
    .insp-tabs {
        display: flex;
        border-bottom: 1px solid var(--line);
    }
    .insp-tab {
        flex: 1;
        padding: 8px 6px;
        text-align: center;
        font-family: var(--mono);
        font-size: 9.5px;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        color: var(--ink-faint);
        cursor: pointer;
        border-bottom: 1px solid transparent;
    }
    .insp-tab:hover { color: var(--ink-dim); }
    .insp-tab.active {
        color: var(--accent);
        border-bottom-color: var(--accent);
        background: linear-gradient(180deg, transparent, rgba(232,163,74,0.06));
    }
    .insp-body {
        padding: 12px;
        flex: 1;
    }
    .insp-panel { display: none; }
    .insp-panel.active { display: block; }
    .section {
        margin-bottom: 16px;
    }
    .section h3 {
        margin: 0 0 8px 0;
        font-family: var(--mono);
        font-size: 9.5px;
        letter-spacing: 0.16em;
        text-transform: uppercase;
        color: var(--ink-faint);
        font-weight: 500;
        display: flex; justify-content: space-between; align-items: center;
    }
    .section h3::before {
        content: ''; flex: 1; height: 1px; background: var(--line);
        margin-right: 8px; order: 2;
    }

    /* Fields */
    .field {
        display: flex; align-items: center;
        margin-bottom: 6px; gap: 8px;
    }
    .field label {
        font-family: var(--mono); font-size: 10.5px;
        color: var(--ink-dim); min-width: 62px;
    }
    .field input[type="number"], .field input[type="text"], .field select {
        flex: 1;
        background: var(--bg-0); border: 1px solid var(--line);
        color: var(--ink); padding: 4px 6px; border-radius: 3px;
        font-family: var(--mono); font-size: 11px;
        outline: none;
    }
    .field input:focus, .field select:focus {
        border-color: var(--accent);
    }
    .field input[type="range"] {
        flex: 1; height: 4px; -webkit-appearance: none;
        background: var(--bg-3); border-radius: 2px; outline: none;
        accent-color: var(--accent);
    }
    .slider-row {
        display: flex; align-items: center; gap: 8px;
        margin-bottom: 8px;
    }
    .slider-row label {
        font-family: var(--mono); font-size: 10.5px;
        color: var(--ink-dim);
        width: 64px;
    }
    .slider-row input[type="range"] {
        flex: 1; height: 4px; -webkit-appearance: none;
        background: var(--bg-3); border-radius: 2px; outline: none;
        accent-color: var(--accent);
    }
    .slider-row .val {
        font-family: var(--mono); font-size: 10.5px;
        color: var(--ink);
        width: 42px; text-align: right;
    }

    button.act-btn {
        background: var(--bg-2);
        border: 1px solid var(--line);
        color: var(--ink);
        padding: 6px 10px;
        border-radius: 3px;
        font-family: var(--sans); font-size: 11.5px;
        cursor: pointer;
        transition: all 0.1s;
    }
    button.act-btn:hover {
        background: var(--bg-3); border-color: var(--line-hi);
    }
    button.act-btn.primary {
        background: var(--accent); color: #1a1612;
        border-color: var(--accent);
        font-weight: 600;
    }
    button.act-btn.primary:hover {
        background: var(--accent-hot);
    }
    button.act-btn:disabled {
        opacity: 0.4; cursor: not-allowed;
    }
    .btn-row {
        display: flex; gap: 4px; flex-wrap: wrap;
    }
    .btn-row button { flex: 1; min-width: 60px; }

    /* Filter grid */
    .filter-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 4px;
    }
    .filter-btn {
        background: var(--bg-2);
        border: 1px solid var(--line);
        color: var(--ink);
        padding: 8px 6px;
        border-radius: 3px;
        font-family: var(--sans); font-size: 11px;
        cursor: pointer;
        text-align: left;
        transition: all 0.1s;
    }
    .filter-btn:hover {
        background: var(--bg-3); border-color: var(--accent-dim);
        color: var(--accent);
    }
    .filter-btn .icn {
        display: inline-block; margin-right: 4px;
        font-size: 12px;
    }

    /* Status bar */
    .statusbar {
        background: var(--bg-1);
        border-top: 1px solid var(--line);
        display: flex;
        align-items: center;
        padding: 0 10px;
        font-family: var(--mono);
        font-size: 10.5px;
        color: var(--ink-dim);
        gap: 16px;
    }
    .statusbar .sb-label { color: var(--ink-faint); }
    .statusbar .sb-val { color: var(--ink); }
    .statusbar .sep { color: var(--ink-faint); }
    .statusbar .grow { flex: 1; }
    #status-msg { color: var(--ink); }
    #status-msg.err { color: var(--danger); }
    #status-msg.ok { color: var(--ok); }

    /* Overlay: init / progress */
    .overlay {
        position: fixed; inset: 0;
        background: rgba(15, 14, 17, 0.88);
        backdrop-filter: blur(4px);
        display: flex; align-items: center; justify-content: center;
        z-index: 1000;
        font-family: var(--mono);
        transition: opacity 0.2s;
    }
    .overlay.hide { opacity: 0; pointer-events: none; }
    .ov-card {
        display: flex; flex-direction: column; align-items: center; gap: 16px;
        padding: 30px 44px;
    }
    .ov-spinner {
        width: 36px; height: 36px;
        border: 2px solid var(--bg-3);
        border-top-color: var(--accent);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    .ov-label {
        font-size: 10.5px;
        letter-spacing: 0.2em;
        text-transform: uppercase;
        color: var(--ink-dim);
    }
    .ov-detail {
        font-size: 10px;
        color: var(--ink-faint);
        margin-top: 4px;
    }

    /* Dialog */
    .dialog-back {
        position: fixed; inset: 0;
        background: rgba(0,0,0,0.55);
        display: none;
        align-items: center; justify-content: center;
        z-index: 200;
    }
    .dialog-back.open { display: flex; }
    .dialog {
        background: var(--bg-1);
        border: 1px solid var(--line-hi);
        border-radius: var(--radius-lg);
        box-shadow: 0 24px 60px rgba(0,0,0,0.6);
        min-width: 360px; max-width: 600px;
        max-height: 70vh;
        display: flex; flex-direction: column;
    }
    .dialog-title {
        padding: 12px 16px;
        font-family: var(--mono);
        font-size: 10.5px;
        letter-spacing: 0.16em;
        text-transform: uppercase;
        color: var(--accent);
        border-bottom: 1px solid var(--line);
    }
    .dialog-body {
        padding: 16px;
        overflow-y: auto;
        flex: 1;
    }
    .dialog-footer {
        padding: 10px 16px;
        border-top: 1px solid var(--line);
        display: flex; justify-content: flex-end; gap: 6px;
    }

    /* FS browser list */
    .fsb-path {
        font-family: var(--mono);
        font-size: 11px;
        background: var(--bg-0);
        border: 1px solid var(--line);
        padding: 6px 8px;
        border-radius: 3px;
        margin-bottom: 8px;
        color: var(--ink);
    }
    .fsb-list {
        border: 1px solid var(--line);
        background: var(--bg-0);
        max-height: 280px;
        min-height: 200px;
        overflow-y: auto;
        border-radius: 3px;
    }
    .fsb-entry {
        padding: 5px 10px;
        cursor: pointer;
        font-family: var(--mono);
        font-size: 11px;
        display: flex; align-items: center; gap: 8px;
        border-bottom: 1px solid rgba(255,255,255,0.03);
    }
    .fsb-entry:hover { background: var(--bg-2); }
    .fsb-entry.sel { background: var(--accent-dim); color: #fff; }
    .fsb-entry .ficon { width: 16px; text-align: center; opacity: 0.7; }
    .fsb-entry .fsize {
        margin-left: auto; color: var(--ink-faint); font-size: 10px;
    }

    /* Scrollbars */
    ::-webkit-scrollbar { width: 10px; height: 10px; }
    ::-webkit-scrollbar-track { background: var(--bg-0); }
    ::-webkit-scrollbar-thumb {
        background: var(--bg-3); border-radius: 5px;
        border: 2px solid var(--bg-0);
    }
    ::-webkit-scrollbar-thumb:hover { background: var(--line-hi); }

    /* Busy indicator in corner */
    .busy {
        position: absolute; top: 8px; right: 8px;
        font-family: var(--mono); font-size: 10px;
        color: var(--accent);
        padding: 4px 10px;
        background: rgba(20,18,22,0.9);
        border: 1px solid var(--accent-dim);
        border-radius: 3px;
        display: none;
        z-index: 10;
    }
    .busy.show { display: block; }
    .busy::before {
        content: '●'; margin-right: 6px;
        animation: pulse 1s ease-in-out infinite;
    }
    @keyframes pulse { 50% { opacity: 0.3; } }
</style>

<!-- ===== SHELL ===== -->
<div id="app">

    <!-- Menubar -->
    <div class="menubar">
        <div class="mb-brand">IMGEDIT</div>
        <button class="mb-btn" data-menu="file">File</button>
        <button class="mb-btn" data-menu="edit">Edit</button>
        <button class="mb-btn" data-menu="image">Image</button>
        <div class="mb-spacer"></div>
        <div class="mb-right" id="fmt-info">—</div>
    </div>

    <!-- Dropdowns (positioned absolutely) -->
    <div class="dropdown" id="menu-file" style="left:76px;">
        <div class="dd-item" data-act="open-fs">Open from Disk…<span class="sh">Ctrl+O</span></div>
        <div class="dd-item" data-act="open-local">Open from Computer…<span class="sh">Ctrl+U</span></div>
        <div class="dd-sep"></div>
        <div class="dd-item" data-act="save">Save<span class="sh">Ctrl+S</span></div>
        <div class="dd-item" data-act="save-as">Save As…</div>
        <div class="dd-item" data-act="export">Export…<span class="sh">Ctrl+E</span></div>
        <div class="dd-sep"></div>
        <div class="dd-item" data-act="close">Close Image</div>
    </div>
    <div class="dropdown" id="menu-edit" style="left:120px;">
        <div class="dd-item" data-act="undo">Undo<span class="sh">Ctrl+Z</span></div>
        <div class="dd-item" data-act="redo">Redo<span class="sh">Ctrl+Y</span></div>
        <div class="dd-sep"></div>
        <div class="dd-item" data-act="revert">Revert to Original</div>
    </div>
    <div class="dropdown" id="menu-image" style="left:166px;">
        <div class="dd-item" data-act="rot-90">Rotate 90° CW</div>
        <div class="dd-item" data-act="rot-270">Rotate 90° CCW</div>
        <div class="dd-item" data-act="rot-180">Rotate 180°</div>
        <div class="dd-sep"></div>
        <div class="dd-item" data-act="flip-h">Flip Horizontal</div>
        <div class="dd-item" data-act="flip-v">Flip Vertical</div>
        <div class="dd-sep"></div>
        <div class="dd-item" data-act="auto-level">Auto Level</div>
        <div class="dd-item" data-act="normalize">Normalize</div>
    </div>

    <!-- Workspace -->
    <div class="workspace">

        <!-- Tool column -->
        <div class="tools">
            <div class="tool" title="Open from Disk (Ctrl+O)" data-act="open-fs">📁</div>
            <div class="tool" title="Open from Computer" data-act="open-local">⬆️</div>
            <div class="tool-sep"></div>
            <div class="tool" title="Save (Ctrl+S)" data-act="save">💾</div>
            <div class="tool" title="Export (Ctrl+E)" data-act="export">📤</div>
            <div class="tool-sep"></div>
            <div class="tool" title="Undo (Ctrl+Z)" data-act="undo">↶</div>
            <div class="tool" title="Redo (Ctrl+Y)" data-act="redo">↷</div>
            <div class="tool-sep"></div>
            <div class="tool" title="Rotate 90°" data-act="rot-90">⟳</div>
            <div class="tool" title="Flip Horizontal" data-act="flip-h">⇄</div>
            <div class="tool" title="Fit to View" data-act="fit">⛶</div>
            <div class="tool" title="Actual Size" data-act="actual">1:1</div>
        </div>

        <!-- Canvas area -->
        <div class="canvas-area" id="canvasArea">
            <div class="canvas-wrap" id="canvasWrap" style="display:none;">
                <img id="preview" draggable="false" />
            </div>
            <div class="empty-state" id="emptyState">
                <div class="big">🖼</div>
                <div>No image loaded</div>
                <div class="act">
                    <button data-act="open-fs">Open from Disk</button>
                    <button data-act="open-local">Upload File</button>
                </div>
            </div>
            <div class="busy" id="busy">Processing…</div>
            <div class="zoom-hud" id="zoomHud" style="display:none;">
                <button data-zoom="out" title="Zoom out">−</button>
                <button data-zoom="fit" title="Fit">⛶</button>
                <div class="zoom-val" id="zoomVal">100%</div>
                <button data-zoom="actual" title="Actual">1:1</button>
                <button data-zoom="in" title="Zoom in">+</button>
            </div>
        </div>

        <!-- Inspector -->
        <div class="inspector">
            <div class="insp-tabs">
                <div class="insp-tab active" data-tab="adjust">Adjust</div>
                <div class="insp-tab" data-tab="transform">Transform</div>
                <div class="insp-tab" data-tab="filters">Filters</div>
            </div>
            <div class="insp-body">

                <!-- ADJUST TAB -->
                <div class="insp-panel active" data-panel="adjust">
                    <div class="section">
                        <h3>Tone</h3>
                        <div class="slider-row">
                            <label>Bright</label>
                            <input type="range" id="adj-brightness" min="-100" max="100" value="0">
                            <div class="val" id="adj-brightness-v">0</div>
                        </div>
                        <div class="slider-row">
                            <label>Contrast</label>
                            <input type="range" id="adj-contrast" min="-100" max="100" value="0">
                            <div class="val" id="adj-contrast-v">0</div>
                        </div>
                        <div class="slider-row">
                            <label>Saturat'n</label>
                            <input type="range" id="adj-saturation" min="-100" max="100" value="0">
                            <div class="val" id="adj-saturation-v">0</div>
                        </div>
                        <div class="slider-row">
                            <label>Hue</label>
                            <input type="range" id="adj-hue" min="-180" max="180" value="0">
                            <div class="val" id="adj-hue-v">0°</div>
                        </div>
                        <div class="btn-row" style="margin-top:8px;">
                            <button class="act-btn" data-act="adj-reset">Reset</button>
                            <button class="act-btn primary" data-act="adj-apply">Apply</button>
                        </div>
                    </div>

                    <div class="section">
                        <h3>Sharpen / Blur</h3>
                        <div class="slider-row">
                            <label>Amount</label>
                            <input type="range" id="sharp-amt" min="0" max="10" step="0.1" value="1">
                            <div class="val" id="sharp-amt-v">1.0</div>
                        </div>
                        <div class="btn-row">
                            <button class="act-btn" data-act="blur">Blur</button>
                            <button class="act-btn" data-act="sharpen">Sharpen</button>
                        </div>
                    </div>
                </div>

                <!-- TRANSFORM TAB -->
                <div class="insp-panel" data-panel="transform">
                    <div class="section">
                        <h3>Resize</h3>
                        <div class="field">
                            <label>Width</label>
                            <input type="number" id="rs-w" min="1">
                        </div>
                        <div class="field">
                            <label>Height</label>
                            <input type="number" id="rs-h" min="1">
                        </div>
                        <div class="field">
                            <label>Lock AR</label>
                            <input type="checkbox" id="rs-lock" checked style="flex:none;accent-color:var(--accent);">
                        </div>
                        <button class="act-btn primary" data-act="resize" style="width:100%;margin-top:4px;">Resize</button>
                    </div>

                    <div class="section">
                        <h3>Rotate</h3>
                        <div class="btn-row">
                            <button class="act-btn" data-act="rot-270">-90°</button>
                            <button class="act-btn" data-act="rot-90">+90°</button>
                            <button class="act-btn" data-act="rot-180">180°</button>
                        </div>
                        <div class="slider-row" style="margin-top:8px;">
                            <label>Angle</label>
                            <input type="range" id="rot-angle" min="-180" max="180" step="1" value="0">
                            <div class="val" id="rot-angle-v">0°</div>
                        </div>
                        <button class="act-btn" data-act="rot-custom" style="width:100%;">Apply Rotation</button>
                    </div>

                    <div class="section">
                        <h3>Flip</h3>
                        <div class="btn-row">
                            <button class="act-btn" data-act="flip-h">⇄ Horizontal</button>
                            <button class="act-btn" data-act="flip-v">⇅ Vertical</button>
                        </div>
                    </div>

                    <div class="section">
                        <h3>Crop</h3>
                        <div class="field">
                            <label>X</label>
                            <input type="number" id="crop-x" min="0" value="0">
                        </div>
                        <div class="field">
                            <label>Y</label>
                            <input type="number" id="crop-y" min="0" value="0">
                        </div>
                        <div class="field">
                            <label>Width</label>
                            <input type="number" id="crop-w" min="1">
                        </div>
                        <div class="field">
                            <label>Height</label>
                            <input type="number" id="crop-h" min="1">
                        </div>
                        <button class="act-btn primary" data-act="crop" style="width:100%;">Apply Crop</button>
                    </div>
                </div>

                <!-- FILTERS TAB -->
                <div class="insp-panel" data-panel="filters">
                    <div class="section">
                        <h3>Color</h3>
                        <div class="filter-grid">
                            <button class="filter-btn" data-fx="grayscale"><span class="icn">◐</span>Grayscale</button>
                            <button class="filter-btn" data-fx="sepia"><span class="icn">⊕</span>Sepia</button>
                            <button class="filter-btn" data-fx="invert"><span class="icn">◑</span>Invert</button>
                            <button class="filter-btn" data-fx="normalize"><span class="icn">∿</span>Normalize</button>
                        </div>
                    </div>
                    <div class="section">
                        <h3>Stylize</h3>
                        <div class="filter-grid">
                            <button class="filter-btn" data-fx="edge"><span class="icn">◰</span>Edge Det.</button>
                            <button class="filter-btn" data-fx="emboss"><span class="icn">▦</span>Emboss</button>
                            <button class="filter-btn" data-fx="charcoal"><span class="icn">✎</span>Charcoal</button>
                            <button class="filter-btn" data-fx="oilpaint"><span class="icn">✦</span>Oil Paint</button>
                            <button class="filter-btn" data-fx="vignette"><span class="icn">◉</span>Vignette</button>
                            <button class="filter-btn" data-fx="solarize"><span class="icn">☀</span>Solarize</button>
                        </div>
                    </div>
                    <div class="section">
                        <h3>Noise</h3>
                        <div class="filter-grid">
                            <button class="filter-btn" data-fx="noise-add"><span class="icn">▒</span>Add Noise</button>
                            <button class="filter-btn" data-fx="noise-remove"><span class="icn">▓</span>Denoise</button>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Status bar -->
    <div class="statusbar">
        <span class="sb-label">SIZE</span><span class="sb-val" id="sb-size">—</span>
        <span class="sep">│</span>
        <span class="sb-label">FORMAT</span><span class="sb-val" id="sb-format">—</span>
        <span class="sep">│</span>
        <span class="sb-label">BYTES</span><span class="sb-val" id="sb-bytes">—</span>
        <span class="grow"></span>
        <span id="status-msg">Ready</span>
    </div>
</div>

<!-- Init overlay -->
<div class="overlay" id="initOverlay">
    <div class="ov-card">
        <div class="ov-spinner"></div>
        <div class="ov-label" id="initLabel">Initializing ImageMagick</div>
        <div class="ov-detail" id="initDetail">Loading runtime from /usr/share/imgedit/…</div>
    </div>
</div>

<!-- Dialog host -->
<div class="dialog-back" id="dialogBack">
    <div class="dialog" id="dialog">
        <div class="dialog-title" id="dlgTitle">Dialog</div>
        <div class="dialog-body" id="dlgBody"></div>
        <div class="dialog-footer" id="dlgFooter"></div>
    </div>
</div>

<!-- Hidden file input for local upload -->
<input type="file" id="localFile" accept="image/*" style="display:none;">

<script type="module">
/* ============================================================
   E-Dog OS — Image Editor (ImageMagick WASM)
   Loads index.js + magick.wasm from /usr/share/imgedit/
============================================================ */

//
// ---------- Utility helpers ----------
//
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

function b64ToBytes(b64) {
    const bin = atob(b64);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
}
function bytesToB64(bytes) {
    let s = '';
    for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    return btoa(s);
}
function fmtBytes(n) {
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    if (n < 1073741824) return (n / 1048576).toFixed(2) + ' MB';
    return (n / 1073741824).toFixed(2) + ' GB';
}
function status(msg, kind = '') {
    const el = $('#status-msg');
    el.textContent = msg;
    el.className = kind;
}
function busy(show, label = 'Processing…') {
    const el = $('#busy');
    el.textContent = label;
    el.classList.toggle('show', !!show);
}

//
// ---------- ImageMagick bootstrap ----------
//
// Loads index.js as a Blob-URL ESM and hands raw WASM bytes to
// initializeImageMagick — no relative fetch, no CORS drama.
//
let IM = null; // { ImageMagick, MagickFormat, Magick, ... }

async function bootstrapImageMagick() {
    const setDetail = (t) => { $('#initDetail').textContent = t; };

    try {
        setDetail('Reading /usr/share/imgedit/index.js…');
        const [jsFile, wasmFile] = await Promise.all([
            fs.readFile('/usr/share/imgedit/index.js'),
            fs.readFile('/usr/share/imgedit/magick.wasm'),
        ]);

        // index.js comes back as text (it's ASCII JavaScript)
        const jsText = jsFile.text;
        if (!jsText) throw new Error('index.js is empty or binary — expected text');

        setDetail('Decoding magick.wasm (' + fmtBytes(wasmFile.size || 0) + ')…');
        // magick.wasm comes back as base64
        if (!wasmFile.base64) throw new Error('magick.wasm is empty or text — expected binary');
        const wasmBytes = b64ToBytes(wasmFile.base64);

        setDetail('Importing ESM module…');
        const blob = new Blob([jsText], { type: 'text/javascript' });
        const url = URL.createObjectURL(blob);
        let mod;
        try {
            mod = await import(url);
        } finally {
            // Keep URL alive briefly in case module does lazy init
            setTimeout(() => URL.revokeObjectURL(url), 2000);
        }

        if (typeof mod.initializeImageMagick !== 'function') {
            throw new Error('Module does not export initializeImageMagick — wrong build?');
        }

        setDetail('Initializing WASM runtime…');
        await mod.initializeImageMagick(wasmBytes);

        IM = mod;
        return true;
    } catch (err) {
        $('#initLabel').textContent = 'Failed to load ImageMagick';
        $('#initDetail').textContent = err.message;
        $('#initDetail').style.color = 'var(--danger)';
        throw err;
    }
}

//
// ---------- Image state ----------
//
const state = {
    // Source-of-truth bytes (PNG, mutated after every op)
    bytes: null,
    originalBytes: null,
    // Display props
    width: 0,
    height: 0,
    format: '',          // last-known MagickFormat value (enum)
    filename: '',
    fsPath: '',          // non-empty if loaded from FS
    // Undo stack
    history: [],
    future: [],
    maxHistory: 30,
    // Zoom
    zoom: 1,
    // Current preview URL (to revoke)
    previewUrl: null,
};

//
// ---------- Core: run an ImageMagick op on current bytes ----------
//
// Fn receives a MagickImage, does stuff synchronously, and returns nothing.
// We write back out to PNG so every op is reversible by re-reading.
//
function runOp(fn, opts = {}) {
    return new Promise((resolve, reject) => {
        if (!state.bytes) { reject(new Error('No image loaded')); return; }
        if (!IM) { reject(new Error('ImageMagick not ready')); return; }

        const outFormat = opts.outFormat ?? IM.MagickFormat.Png;

        try {
            IM.ImageMagick.read(state.bytes, (img) => {
                try {
                    fn(img);
                    img.write(outFormat, (data) => {
                        // data is Uint8Array owned by WASM heap — copy it
                        const copy = new Uint8Array(data.length);
                        copy.set(data);
                        pushHistory();
                        state.bytes = copy;
                        state.width = img.width;
                        state.height = img.height;
                        refreshPreview();
                        resolve();
                    });
                } catch (e) { reject(e); }
            });
        } catch (e) { reject(e); }
    });
}

function pushHistory() {
    state.history.push(state.bytes);
    if (state.history.length > state.maxHistory) state.history.shift();
    state.future = [];
}

async function undo() {
    if (state.history.length === 0) { status('Nothing to undo'); return; }
    state.future.push(state.bytes);
    state.bytes = state.history.pop();
    await refreshDimsFromBytes();
    refreshPreview();
    status('Undo');
}
async function redo() {
    if (state.future.length === 0) { status('Nothing to redo'); return; }
    state.history.push(state.bytes);
    state.bytes = state.future.pop();
    await refreshDimsFromBytes();
    refreshPreview();
    status('Redo');
}

// Re-read an image just to get its dimensions (for undo/redo)
function refreshDimsFromBytes() {
    return new Promise(resolve => {
        IM.ImageMagick.read(state.bytes, (img) => {
            state.width = img.width; state.height = img.height;
            resolve();
        });
    });
}

//
// ---------- Preview refresh ----------
//
function refreshPreview() {
    if (state.previewUrl) URL.revokeObjectURL(state.previewUrl);
    const blob = new Blob([state.bytes], { type: 'image/png' });
    state.previewUrl = URL.createObjectURL(blob);
    $('#preview').src = state.previewUrl;
    $('#canvasWrap').style.display = 'block';
    $('#emptyState').style.display = 'none';
    $('#zoomHud').style.display = 'flex';

    // Stats
    $('#sb-size').textContent = state.width + ' × ' + state.height + ' px';
    $('#sb-bytes').textContent = fmtBytes(state.bytes.length);
    $('#sb-format').textContent = state.format || 'PNG';
    $('#fmt-info').textContent = (state.filename || 'untitled') + '  ·  '
        + state.width + '×' + state.height;

    // Prefill resize/crop defaults
    const rsW = $('#rs-w'), rsH = $('#rs-h');
    if (!rsW.dataset.touched) { rsW.value = state.width; rsH.value = state.height; }
    const cw = $('#crop-w'), ch = $('#crop-h');
    if (!cw.value || cw.value === '0') cw.value = state.width;
    if (!ch.value || ch.value === '0') ch.value = state.height;

    fitZoom();
}

//
// ---------- Loading images ----------
//
async function loadBytes(bytes, filename, fsPath = '') {
    if (!IM) { status('ImageMagick not ready', 'err'); return; }

    try {
        await new Promise((resolve, reject) => {
            IM.ImageMagick.read(bytes, (img) => {
                try {
                    state.width = img.width;
                    state.height = img.height;
                    state.format = img.format;
                    // Normalize internal storage to PNG so subsequent ops
                    // are predictable regardless of input format.
                    img.write(IM.MagickFormat.Png, (data) => {
                        const copy = new Uint8Array(data.length);
                        copy.set(data);
                        state.bytes = copy;
                        state.originalBytes = copy;
                        resolve();
                    });
                } catch (e) { reject(e); }
            });
        });
        state.filename = filename;
        state.fsPath = fsPath;
        state.history = [];
        state.future = [];
        refreshPreview();
        status('Loaded ' + filename, 'ok');
    } catch (err) {
        status('Failed to load: ' + err.message, 'err');
    }
}

async function openFromFS(path) {
    try {
        busy(true, 'Reading…');
        const f = await fs.readFile(path);
        let bytes;
        if (f.base64) bytes = b64ToBytes(f.base64);
        else if (f.text != null) {
            // Some odd formats (SVG) come back as text
            bytes = new TextEncoder().encode(f.text);
        } else {
            throw new Error('File is empty');
        }
        await loadBytes(bytes, f.name || path.split('/').pop(), path);
    } catch (e) {
        status('Open failed: ' + e.message, 'err');
    } finally {
        busy(false);
    }
}

function openLocal() {
    $('#localFile').click();
}
$('#localFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    busy(true, 'Reading file…');
    const buf = await file.arrayBuffer();
    await loadBytes(new Uint8Array(buf), file.name);
    busy(false);
    e.target.value = ''; // allow re-selecting same file
});

//
// ---------- Operations ----------
//
const OPS = {
    // Transforms
    'rot-90': () => runOp(img => img.rotate(90)),
    'rot-180': () => runOp(img => img.rotate(180)),
    'rot-270': () => runOp(img => img.rotate(270)),
    'rot-custom': () => {
        const a = parseFloat($('#rot-angle').value) || 0;
        if (a === 0) { status('Rotation is 0° — no-op'); return; }
        return runOp(img => img.rotate(a));
    },
    'flip-h': () => runOp(img => img.flop()),    // horizontal
    'flip-v': () => runOp(img => img.flip()),    // vertical
    'resize': () => {
        const w = parseInt($('#rs-w').value, 10);
        const h = parseInt($('#rs-h').value, 10);
        if (!w || !h) { status('Enter valid dimensions', 'err'); return; }
        return runOp(img => img.resize(w, h));
    },
    'crop': () => {
        const x = parseInt($('#crop-x').value, 10) || 0;
        const y = parseInt($('#crop-y').value, 10) || 0;
        const w = parseInt($('#crop-w').value, 10);
        const h = parseInt($('#crop-h').value, 10);
        if (!w || !h) { status('Enter crop width/height', 'err'); return; }
        return runOp(img => {
            // MagickGeometry constructor varies by build; use static helper
            const geom = new IM.MagickGeometry(x, y, w, h);
            img.crop(geom);
            img.repage(); // re-origin the canvas
        });
    },

    // Adjustments (Apply button)
    'adj-apply': async () => {
        const b = parseFloat($('#adj-brightness').value);
        const c = parseFloat($('#adj-contrast').value);
        const s = parseFloat($('#adj-saturation').value);
        const h = parseFloat($('#adj-hue').value);
        if (b === 0 && c === 0 && s === 0 && h === 0) {
            status('No adjustments to apply'); return;
        }
        await runOp(img => {
            // brightnessContrast: (-100..100, -100..100)
            if (b !== 0 || c !== 0) img.brightnessContrast(b, c);
            // modulate: brightness, saturation, hue — each as percent (100 = unchanged)
            if (s !== 0 || h !== 0) {
                const sat = 100 + s;
                const hue = 100 + (h / 180) * 100; // -180..180 → 0..200
                img.modulate(new IM.Percentage(100), new IM.Percentage(sat), new IM.Percentage(hue));
            }
        });
        // reset sliders
        ['adj-brightness','adj-contrast','adj-saturation','adj-hue'].forEach(id => {
            $('#' + id).value = 0;
            $('#' + id + '-v').textContent = id === 'adj-hue' ? '0°' : '0';
        });
    },
    'adj-reset': () => {
        ['adj-brightness','adj-contrast','adj-saturation','adj-hue'].forEach(id => {
            $('#' + id).value = 0;
            $('#' + id + '-v').textContent = id === 'adj-hue' ? '0°' : '0';
        });
        status('Adjustments reset');
    },

    'blur':    () => runOp(img => img.blur(0, parseFloat($('#sharp-amt').value))),
    'sharpen': () => runOp(img => img.sharpen(0, parseFloat($('#sharp-amt').value))),

    // Menu ops
    'auto-level': () => runOp(img => img.autoLevel()),
    'normalize':  () => runOp(img => img.normalize()),

    // History
    'undo': undo,
    'redo': redo,
    'revert': async () => {
        if (!state.originalBytes) return;
        pushHistory();
        state.bytes = state.originalBytes;
        await refreshDimsFromBytes();
        refreshPreview();
        status('Reverted to original');
    },

    // File ops
    'open-fs': () => openFSBrowser(),
    'open-local': openLocal,
    'save': () => saveToFS(false),
    'save-as': () => saveToFS(true),
    'export': () => openExportDialog(),
    'close': closeImage,

    // Zoom
    'fit': fitZoom,
    'actual': () => setZoom(1),
};

// Filter effects (separate table so we can enumerate)
const FX = {
    grayscale: img => img.grayscale(),
    sepia:     img => img.sepiaTone(new IM.Percentage(80)),
    invert:    img => img.negate(),
    normalize: img => img.normalize(),
    edge:      img => img.edge(1),
    emboss:    img => img.emboss(),
    charcoal:  img => img.charcoal(),
    oilpaint:  img => img.oilPaint(3),
    vignette:  img => img.vignette(0, 20, 10, 10),
    solarize:  img => img.solarize(new IM.Percentage(50)),
    'noise-add':    img => img.addNoise(IM.NoiseType.Gaussian),
    'noise-remove': img => img.enhance(),
};

function closeImage() {
    state.bytes = null;
    state.originalBytes = null;
    state.history = [];
    state.future = [];
    state.filename = '';
    state.fsPath = '';
    if (state.previewUrl) { URL.revokeObjectURL(state.previewUrl); state.previewUrl = null; }
    $('#canvasWrap').style.display = 'none';
    $('#emptyState').style.display = 'block';
    $('#zoomHud').style.display = 'none';
    $('#sb-size').textContent = '—';
    $('#sb-format').textContent = '—';
    $('#sb-bytes').textContent = '—';
    $('#fmt-info').textContent = '—';
    status('Closed');
}

//
// ---------- Export ----------
//
const FORMAT_MAP = [
    { id: 'Png',  ext: 'png',  mime: 'image/png',   quality: false },
    { id: 'Jpeg', ext: 'jpg',  mime: 'image/jpeg',  quality: true  },
    { id: 'WebP', ext: 'webp', mime: 'image/webp',  quality: true  },
    { id: 'Gif',  ext: 'gif',  mime: 'image/gif',   quality: false },
    { id: 'Bmp',  ext: 'bmp',  mime: 'image/bmp',   quality: false },
    { id: 'Tiff', ext: 'tiff', mime: 'image/tiff',  quality: false },
    { id: 'Avif', ext: 'avif', mime: 'image/avif',  quality: true  },
];

function encode(formatId, quality) {
    return new Promise((resolve, reject) => {
        IM.ImageMagick.read(state.bytes, (img) => {
            try {
                if (quality != null) img.quality = quality;
                const mf = IM.MagickFormat[formatId];
                if (mf === undefined) { reject(new Error('Unknown format: ' + formatId)); return; }
                img.write(mf, (data) => {
                    const copy = new Uint8Array(data.length);
                    copy.set(data);
                    resolve(copy);
                });
            } catch (e) { reject(e); }
        });
    });
}

function openExportDialog() {
    if (!state.bytes) { status('No image loaded', 'err'); return; }

    const body = $('#dlgBody');
    body.innerHTML = `
        <div class="field">
            <label>Format</label>
            <select id="expFmt">${FORMAT_MAP.map(f => '<option value="'+f.id+'">'+f.id.toUpperCase()+' (.'+f.ext+')</option>').join('')}</select>
        </div>
        <div class="slider-row" id="qualityRow">
            <label>Quality</label>
            <input type="range" id="expQ" min="1" max="100" value="90">
            <div class="val" id="expQv">90</div>
        </div>
        <div class="field">
            <label>Destination</label>
            <select id="expDest">
                <option value="download">Download to Computer</option>
                <option value="fs">Save to E-Dog OS</option>
            </select>
        </div>
        <div class="field" id="expPathRow" style="display:none;">
            <label>FS Path</label>
            <input type="text" id="expPath" value="" placeholder="/home/user/image.png">
        </div>
    `;
    $('#dlgTitle').textContent = 'Export Image';
    setFooter([
        { label: 'Cancel', cb: closeDialog },
        { label: 'Export', primary: true, cb: doExport },
    ]);
    showDialog();

    const fmtEl = $('#expFmt'), qEl = $('#expQ'), qv = $('#expQv'),
          qRow = $('#qualityRow'), destEl = $('#expDest'),
          pathEl = $('#expPath'), pathRow = $('#expPathRow');

    qEl.oninput = () => { qv.textContent = qEl.value; };
    const updateQ = () => {
        const fmt = FORMAT_MAP.find(f => f.id === fmtEl.value);
        qRow.style.display = fmt.quality ? 'flex' : 'none';
        updatePath();
    };
    const updatePath = () => {
        const fmt = FORMAT_MAP.find(f => f.id === fmtEl.value);
        const base = (state.filename || 'image').replace(/\.[^.]+$/, '');
        const baseDir = state.fsPath ? state.fsPath.replace(/\/[^/]+$/, '') : (fs.home + '/Pictures');
        pathEl.value = baseDir + '/' + base + '.' + fmt.ext;
    };
    fmtEl.onchange = updateQ;
    destEl.onchange = () => {
        pathRow.style.display = destEl.value === 'fs' ? 'flex' : 'none';
    };
    updateQ();
}

async function doExport() {
    const fmt = $('#expFmt').value;
    const q = parseInt($('#expQ').value, 10);
    const dest = $('#expDest').value;
    const path = $('#expPath').value.trim();
    const info = FORMAT_MAP.find(f => f.id === fmt);

    closeDialog();
    busy(true, 'Encoding ' + fmt + '…');
    try {
        const bytes = await encode(fmt, info.quality ? q : null);
        if (dest === 'download') {
            const blob = new Blob([bytes], { type: info.mime });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            const base = (state.filename || 'image').replace(/\.[^.]+$/, '');
            a.href = url; a.download = base + '.' + info.ext;
            document.body.appendChild(a); a.click(); a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
            status('Downloaded as ' + a.download, 'ok');
        } else {
            await fs.writeFile(path, { base64: bytesToB64(bytes) });
            status('Saved to ' + path, 'ok');
        }
    } catch (e) {
        status('Export failed: ' + e.message, 'err');
    } finally {
        busy(false);
    }
}

async function saveToFS(forceNew) {
    if (!state.bytes) { status('No image loaded', 'err'); return; }
    let path = state.fsPath;
    if (forceNew || !path) {
        // Quick path prompt via dialog
        openSaveAsDialog();
        return;
    }
    // Detect extension and encode appropriately
    const ext = path.split('.').pop().toLowerCase();
    const info = FORMAT_MAP.find(f => f.ext === ext) || FORMAT_MAP[0];
    busy(true, 'Saving…');
    try {
        const bytes = await encode(info.id, info.quality ? 92 : null);
        await fs.writeFile(path, { base64: bytesToB64(bytes) });
        status('Saved to ' + path, 'ok');
    } catch (e) {
        status('Save failed: ' + e.message, 'err');
    } finally {
        busy(false);
    }
}

function openSaveAsDialog() {
    const body = $('#dlgBody');
    const base = (state.filename || 'image').replace(/\.[^.]+$/, '');
    const baseDir = state.fsPath ? state.fsPath.replace(/\/[^/]+$/, '') : (fs.home + '/Pictures');
    body.innerHTML = `
        <div class="field">
            <label>FS Path</label>
            <input type="text" id="saPath" value="${baseDir}/${base}.png">
        </div>
        <div style="font-family:var(--mono);font-size:10px;color:var(--ink-faint);margin-top:6px;">
            Format is auto-detected from the file extension.
        </div>
    `;
    $('#dlgTitle').textContent = 'Save As';
    setFooter([
        { label: 'Cancel', cb: closeDialog },
        { label: 'Save', primary: true, cb: async () => {
            const path = $('#saPath').value.trim();
            if (!path) return;
            closeDialog();
            state.fsPath = path;
            state.filename = path.split('/').pop();
            await saveToFS(false);
        } },
    ]);
    showDialog();
}

//
// ---------- FS Browser Dialog ----------
//
async function openFSBrowser() {
    let curPath = state.fsPath
        ? state.fsPath.replace(/\/[^/]+$/, '')
        : (fs.home + '/Pictures');
    // Fall back if that directory doesn't exist
    try { await fs.listDir(curPath); }
    catch { curPath = fs.home; }
    let selected = null;

    const body = $('#dlgBody');
    body.innerHTML = `
        <div class="fsb-path" id="fsbPath"></div>
        <div class="fsb-list" id="fsbList"></div>
        <div style="font-family:var(--mono);font-size:10px;color:var(--ink-faint);margin-top:6px;">
            Double-click folders to open. Click images to select.
        </div>
    `;
    $('#dlgTitle').textContent = 'Open Image';

    const okBtn = { label: 'Open', primary: true, cb: async () => {
        if (!selected) return;
        closeDialog();
        await openFromFS(curPath + '/' + selected);
    }};
    setFooter([{ label: 'Cancel', cb: closeDialog }, okBtn]);

    async function render() {
        $('#fsbPath').textContent = curPath;
        const list = await fs.listDir(curPath);
        const listEl = $('#fsbList');
        listEl.innerHTML = '';

        // ".." entry
        if (curPath !== '/') {
            const up = document.createElement('div');
            up.className = 'fsb-entry';
            up.innerHTML = '<span class="ficon">↑</span><span>..</span>';
            up.ondblclick = () => {
                curPath = curPath.replace(/\/[^/]+$/, '') || '/';
                selected = null; render();
            };
            listEl.appendChild(up);
        }

        // Sort: folders first, then files alphabetically
        list.sort((a, b) => {
            if (a.type !== b.type) return a.type === 'folder' ? -1 : 1;
            return a.name.localeCompare(b.name);
        });

        for (const item of list) {
            const isImg = /\.(png|jpe?g|gif|bmp|tiff?|webp|avif|ico|svg)$/i.test(item.name);
            if (item.type === 'file' && !isImg) continue; // hide non-images for clarity

            const row = document.createElement('div');
            row.className = 'fsb-entry';
            const icon = item.type === 'folder' ? '📁' : '🖼';
            row.innerHTML = `
                <span class="ficon">${icon}</span>
                <span>${item.name}</span>
                <span class="fsize">${item.type === 'file' ? fmtBytes(item.size || 0) : ''}</span>
            `;
            row.onclick = () => {
                $$('.fsb-entry', listEl).forEach(e => e.classList.remove('sel'));
                if (item.type === 'file') {
                    row.classList.add('sel');
                    selected = item.name;
                }
            };
            row.ondblclick = async () => {
                if (item.type === 'folder') {
                    curPath = curPath.replace(/\/$/, '') + '/' + item.name;
                    selected = null; render();
                } else {
                    closeDialog();
                    await openFromFS(curPath + '/' + item.name);
                }
            };
            listEl.appendChild(row);
        }
    }

    showDialog();
    render().catch(e => {
        $('#fsbList').innerHTML = '<div style="padding:10px;color:var(--danger)">Error: ' + e.message + '</div>';
    });
}

//
// ---------- Dialog helpers ----------
//
function showDialog() { $('#dialogBack').classList.add('open'); }
function closeDialog() { $('#dialogBack').classList.remove('open'); }
function setFooter(buttons) {
    const f = $('#dlgFooter');
    f.innerHTML = '';
    for (const b of buttons) {
        const btn = document.createElement('button');
        btn.className = 'act-btn' + (b.primary ? ' primary' : '');
        btn.textContent = b.label;
        btn.onclick = b.cb;
        f.appendChild(btn);
    }
}
$('#dialogBack').addEventListener('click', (e) => {
    if (e.target === $('#dialogBack')) closeDialog();
});

//
// ---------- Zoom ----------
//
function setZoom(z) {
    state.zoom = z;
    $('#canvasWrap').style.transform = 'scale(' + z + ')';
    $('#zoomVal').textContent = Math.round(z * 100) + '%';
}
function fitZoom() {
    if (!state.width) return;
    const area = $('#canvasArea').getBoundingClientRect();
    const pad = 40;
    const zW = (area.width  - pad) / state.width;
    const zH = (area.height - pad) / state.height;
    setZoom(Math.min(1, Math.min(zW, zH)));
}
$('#zoomHud').addEventListener('click', (e) => {
    const z = e.target.dataset?.zoom;
    if (!z) return;
    if (z === 'in')  setZoom(Math.min(8, state.zoom * 1.25));
    if (z === 'out') setZoom(Math.max(0.05, state.zoom / 1.25));
    if (z === 'fit') fitZoom();
    if (z === 'actual') setZoom(1);
});
$('#canvasArea').addEventListener('wheel', (e) => {
    if (!state.bytes) return;
    if (!(e.ctrlKey || e.metaKey)) return;
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.1 : 1 / 1.1;
    setZoom(Math.max(0.05, Math.min(8, state.zoom * factor)));
}, { passive: false });

//
// ---------- UI wiring ----------
//
function wireAction(el) {
    const act = el.dataset.act;
    if (!act) return;
    el.addEventListener('click', () => {
        if (OPS[act]) {
            const res = OPS[act]();
            if (res && res.then) {
                busy(true);
                res
                    .then(() => status('Done: ' + act, 'ok'))
                    .catch(e => status('Error: ' + e.message, 'err'))
                    .finally(() => busy(false));
            }
        }
    });
}
$$('[data-act]').forEach(wireAction);
$$('[data-fx]').forEach(el => {
    el.addEventListener('click', async () => {
        const fx = el.dataset.fx;
        if (!FX[fx]) return;
        busy(true, 'Applying ' + fx + '…');
        try {
            await runOp(img => FX[fx](img));
            status('Applied ' + fx, 'ok');
        } catch (e) {
            status('Error: ' + e.message, 'err');
        } finally {
            busy(false);
        }
    });
});

// Menu buttons (File / Edit / Image)
const menus = { file: $('#menu-file'), edit: $('#menu-edit'), image: $('#menu-image') };
$$('.mb-btn[data-menu]').forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const m = btn.dataset.menu;
        const open = menus[m].classList.contains('open');
        Object.values(menus).forEach(x => x.classList.remove('open'));
        if (!open) menus[m].classList.add('open');
    });
});
document.addEventListener('click', () => {
    Object.values(menus).forEach(x => x.classList.remove('open'));
});

// Inspector tabs
$$('.insp-tab').forEach(tab => {
    tab.addEventListener('click', () => {
        const name = tab.dataset.tab;
        $$('.insp-tab').forEach(t => t.classList.toggle('active', t === tab));
        $$('.insp-panel').forEach(p => p.classList.toggle('active', p.dataset.panel === name));
    });
});

// Slider value displays
function bindSlider(id, fmt = (v) => v) {
    const el = $('#' + id), out = $('#' + id + '-v');
    const upd = () => { out.textContent = fmt(el.value); };
    el.addEventListener('input', upd); upd();
}
bindSlider('adj-brightness');
bindSlider('adj-contrast');
bindSlider('adj-saturation');
bindSlider('adj-hue', v => v + '°');
bindSlider('sharp-amt', v => parseFloat(v).toFixed(1));
bindSlider('rot-angle', v => v + '°');

// Resize aspect ratio lock
const rsW = $('#rs-w'), rsH = $('#rs-h'), rsLock = $('#rs-lock');
let _rsUpd = false;
rsW.addEventListener('input', () => {
    rsW.dataset.touched = '1';
    if (!rsLock.checked || !state.width || _rsUpd) return;
    _rsUpd = true;
    rsH.value = Math.max(1, Math.round(rsW.value * state.height / state.width));
    _rsUpd = false;
});
rsH.addEventListener('input', () => {
    rsH.dataset.touched = '1';
    if (!rsLock.checked || !state.height || _rsUpd) return;
    _rsUpd = true;
    rsW.value = Math.max(1, Math.round(rsH.value * state.width / state.height));
    _rsUpd = false;
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    if ($('#dialogBack').classList.contains('open')) {
        if (e.key === 'Escape') closeDialog();
        return;
    }
    const mod = e.ctrlKey || e.metaKey;
    if (!mod) return;
    const k = e.key.toLowerCase();
    const map = {
        'o': 'open-fs', 'u': 'open-local',
        's': 'save', 'e': 'export',
        'z': 'undo', 'y': 'redo',
    };
    if (map[k]) {
        e.preventDefault();
        const r = OPS[map[k]]?.();
        if (r && r.then) r.catch(err => status('Error: ' + err.message, 'err'));
    }
});

// Window resize → refit if fit mode-ish
window.addEventListener('resize', () => {
    if (state.bytes) fitZoom();
});

//
// ---------- Kick things off ----------
//
(async () => {
    try {
        await bootstrapImageMagick();
        // Hide init overlay
        $('#initOverlay').classList.add('hide');
        setTimeout(() => { $('#initOverlay').style.display = 'none'; }, 220);
        status('ImageMagick ready — open an image to begin', 'ok');
        const v = IM.Magick?.imageMagickVersion || 'ready';
        $('#initDetail').textContent = v;
    } catch (err) {
        console.error(err);
        // Overlay stays up showing the error
    }
})();

</script>
\\\CODEEND
